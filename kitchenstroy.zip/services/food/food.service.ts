import { Injectable } from '@angular/core';
import { Food } from 'src/app/shared/models/Food';
import { Tag } from 'src/app/shared/models/Tag';
@Injectable({
  providedIn: 'root'
})
export class FoodService {

  constructor() { }

  getFoodById(id:number):Food{
    return this.getAll().find(food=>food.id == id)!;
  }

  getAlltags():Tag[]{
    return[
      {name:'All',count:6},
      {name:'Fastfood',count:3},
      {name:'Breakfast',count:2},
      {name:'Starter',count:1},
      {name:'Meal',count:2}

    ]
  }
  getAllFoodsBySearchTerm(searchTerm:string):Food[]{
    return this.getAll().filter(food =>
      food.name.toLowerCase().includes(searchTerm.toLowerCase()));
  }

  getAllFoodsByTag(tag:string):Food[]{
return tag == "All"?
this.getAll():
this.getAll().filter(food =>food.tags?.includes(tag));
  }

  getAll():Food[]{
    return[
      {
        id:1,
        name:'Idli',
        cookTime:'15-25',
        price:6,
        favorite:false,
        origins:['India'],
        stars:4.5,
        imageUrl:'/assets/images/idli.jpg',
        tags:['Breakfast'],
       },
       {
        id:2,
        name:'Biryani',
        cookTime:'25-30',
        price:5,
        favorite:false,
        origins:['India'],
        stars:4.5,
        imageUrl:'/assets/images/biryani.jpg',
        tags:['Meal'],
       },
     
     {
      id:3,
      name:'Frenchfries',
      cookTime:'15-25',
      price:5,
      favorite:false,
      origins:['France'],
      stars:4.5,
      imageUrl:'/assets/images/frenchfries.jpg',
      tags:['Fastfood'],
     },
    
     {
      id:4,
      name:'Paratha',
      cookTime:'15-25',
      price:3,
      favorite:false,
      origins:['India'],
      stars:4.5,
      imageUrl:'/assets/images/parata1.jpg',
      tags:['Breakfast'],
     },
    
     {
      id:5,
      name:'Dosa',
      cookTime:'25-30',
      price:5,
      favorite:false,
      origins:['India'],
      stars:4.5,
      imageUrl:'/assets/images/d.jpg',
      tags:['Fastfood'],
     },
     {
      id:6,
      name:'Chicken-Chilly',
      cookTime:'25-30',
      price:8,
      favorite:false,
      origins:['India'],
      stars:4.5,
      imageUrl:'/assets/images/chickn.jpg',
      tags:['Starter'],
     },
     {
      id:7,
      name:'Pizza',
      cookTime:'25-30',
      price:10,
      favorite:false,
      origins:['America'],
      stars:4.5,
      imageUrl:'/assets/images/piz.jpg',
      tags:['Fastfood'],
     },
     {
      id:8,
      name:'Veg-Thali',
      cookTime:'25-30',
      price:10,
      favorite:false,
      origins:['India'],
      stars:4.5,
      imageUrl:'/assets/images/veg.jpg',
      tags:['Meal'],
     },
     
    
    ]
  }
}
