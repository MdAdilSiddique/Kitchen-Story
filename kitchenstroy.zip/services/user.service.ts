import { Injectable } from '@angular/core';
import { User } from '../shared/models/User';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  [x: string]: any;
   public userObservable:Observable<User> | undefined;
  constructor() {
    this.userObservable = this.userSubject.asObservable();
   }
   public get currentUser():User{
          return this.userSubject.value;
   }

}

